import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector:'app-navbar',
  templateUrl:'./navbar.component.html',
  styleUrls:['./navbar.component.scss']
})

export class NavbarComponent{

  darkMode=false;

  constructor(private router:Router){}

  toggleTheme(){

    this.darkMode=!this.darkMode;

    document.body.classList.toggle('dark-mode');
  }

  logout(){

    localStorage.clear();

    this.router.navigate(['/']);
  }
}
