import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { HomeComponent } from './features/home/home.component';

import { LoginComponent } from './features/auth/login/login.component';
import { RegisterComponent } from './features/auth/register/register.component';
import { RecoverPasswordComponent } from './features/auth/recover-password/recover-password.component';

import { SimulatorComponent } from './features/simulator/simulator/simulator.component';

import { ProfileComponent } from './features/profile/profile.component';

import { TransactionFormComponent } from './features/transactions/transaction-form/transaction-form.component';

import { InstructorCommentsComponent } from './features/evaluation/instructor-comments/instructor-comments.component';

const routes: Routes = [

  {
    path:'',
    component:HomeComponent
  },

  {
    path:'login',
    component:LoginComponent
  },

  {
    path:'register',
    component:RegisterComponent
  },

  {
    path:'recover-password',
    component:RecoverPasswordComponent
  },

  {
    path:'simulator',
    component:SimulatorComponent
  },

  {
    path:'profile',
    component:ProfileComponent
  },

  {
    path:'transactions',
    component:TransactionFormComponent
  },

  {
    path:'evaluation',
    component:InstructorCommentsComponent
  },

  {
    path:'**',
    redirectTo:''
  }

];

@NgModule({
  imports:[RouterModule.forRoot(routes)],
  exports:[RouterModule]
})

export class AppRoutingModule{}
